using System;
using System.Text.Json.Serialization;

namespace MyAvaloniaApp.Models;

public class Miembro
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string Apellido { get; set; } = "";
    public string Dni { get; set; } = "";
    public string? Email { get; set; }
    public string? Telefono { get; set; }
    public DateTime FechaAlta { get; set; } = DateTime.Today;
    public bool Activo { get; set; } = true;

    [JsonIgnore] public string NombreCompleto => $"{Apellido}, {Nombre}";
    [JsonIgnore] public string Estado => Activo ? "Activo" : "Inactivo";
}

public class Entrenador
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string Apellido { get; set; } = "";
    public string Especialidad { get; set; } = "";
    public string? Email { get; set; }

    [JsonIgnore] public string NombreCompleto => $"{Apellido}, {Nombre}";
}

public class Maquina
{
    public int Id { get; set; }
    public string Nombre { get; set; } = "";
    public string Musculo { get; set; } = "";
}

public class Pago
{
    public int Id { get; set; }
    public int MiembroId { get; set; }
    public string MiembroNombre { get; set; } = "";
    public decimal Monto { get; set; }
    public DateTime Fecha { get; set; } = DateTime.Today;
    public string Concepto { get; set; } = "";
}

public class PagoRequest
{
    public int MiembroId { get; set; }
    public decimal Monto { get; set; }
    public DateTime Fecha { get; set; } = DateTime.Today;
    public string Concepto { get; set; } = "";
}

public class LoginRequest
{
    public string Usuario { get; set; } = "";
    public string Clave { get; set; } = "";
}
