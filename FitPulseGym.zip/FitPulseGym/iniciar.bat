@echo off
setlocal
cd /d "%~dp0"
title FitPulse Gym - Iniciador

where dotnet >nul 2>nul
if errorlevel 1 (
  echo No se encontro el SDK de .NET. Instale el SDK de .NET 10 y vuelva a intentar.
  pause
  exit /b 1
)

echo [1/2] Iniciando la API (primera vez: descarga paquetes y crea la base de datos)...
start "FitPulse API" cmd /k dotnet run --project GymApi\GymApi.csproj --urls http://localhost:5080

echo Esperando a que la API responda...
powershell -NoProfile -Command "for($i=0;$i -lt 90;$i++){ try { Invoke-WebRequest http://localhost:5080/api/salud -UseBasicParsing -TimeoutSec 2 | Out-Null; exit 0 } catch { Start-Sleep -Seconds 1 } }; exit 1"
if errorlevel 1 (
  echo La API no respondio. Revise la ventana "FitPulse API" para ver el error.
  pause
  exit /b 1
)

echo [2/2] Iniciando la aplicacion de escritorio...
dotnet run --project GymAvalonia\MyAvaloniaApp.csproj

echo.
echo Cierre la ventana "FitPulse API" para detener el servidor.
pause
