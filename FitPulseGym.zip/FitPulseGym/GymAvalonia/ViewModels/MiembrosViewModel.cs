using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MyAvaloniaApp.Models;
using MyAvaloniaApp.Services;

namespace MyAvaloniaApp.ViewModels;

public partial class MiembrosViewModel : ViewModelBase
{
    private readonly MainWindowViewModel _mainViewModel;

    public ObservableCollection<Miembro> Miembros { get; } = new();

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(TituloFormulario))]
    private Miembro? _seleccionado;

    [ObservableProperty] private string _nombre = "";
    [ObservableProperty] private string _apellido = "";
    [ObservableProperty] private string _dni = "";
    [ObservableProperty] private string _email = "";
    [ObservableProperty] private string _telefono = "";
    [ObservableProperty] private bool _activo = true;

    public string TituloFormulario => Seleccionado is null ? "Nuevo miembro" : "Editar miembro";

    public MiembrosViewModel(MainWindowViewModel mainViewModel)
    {
        _mainViewModel = mainViewModel;
        _ = CargarAsync();
    }

    partial void OnSeleccionadoChanged(Miembro? value)
    {
        if (value is null)
        {
            LimpiarCampos();
            return;
        }

        Nombre = value.Nombre;
        Apellido = value.Apellido;
        Dni = value.Dni;
        Email = value.Email ?? "";
        Telefono = value.Telefono ?? "";
        Activo = value.Activo;
        ErrorMessage = null;
        InfoMessage = null;
    }

    private void LimpiarCampos()
    {
        Nombre = Apellido = Dni = Email = Telefono = "";
        Activo = true;
    }

    private async Task CargarListaAsync()
    {
        var lista = await Api.GetAsync<List<Miembro>>("api/miembros");
        Miembros.Clear();
        foreach (var m in lista) Miembros.Add(m);
        SinDatos = Miembros.Count == 0;
    }

    [RelayCommand]
    private Task CargarAsync() => RunAsync(CargarListaAsync);

    [RelayCommand]
    private void Nuevo()
    {
        ErrorMessage = null;
        InfoMessage = null;
        Seleccionado = null;
        LimpiarCampos();
    }

    [RelayCommand]
    private async Task GuardarAsync()
    {
        var errores = new List<string>();
        Validador.Requerido(errores, Nombre, "El nombre");
        Validador.Requerido(errores, Apellido, "El apellido");
        Validador.Dni(errores, Dni);
        Validador.Email(errores, Email);
        Validador.Telefono(errores, Telefono);
        if (errores.Count > 0)
        {
            SetError("Revise los datos ingresados:\n" + string.Join("\n", errores));
            return;
        }

        var datos = new Miembro
        {
            Nombre = Nombre.Trim(),
            Apellido = Apellido.Trim(),
            Dni = Dni.Trim(),
            Email = Validador.NullSiVacio(Email),
            Telefono = Validador.NullSiVacio(Telefono),
            Activo = Activo
        };
        var editando = Seleccionado;

        await RunAsync(async () =>
        {
            if (editando is null)
                await Api.PostAsync<Miembro>("api/miembros", datos);
            else
                await Api.PutAsync($"api/miembros/{editando.Id}", datos);

            await CargarListaAsync();
            Seleccionado = null;
            LimpiarCampos();
        }, editando is null ? "Miembro registrado correctamente." : "Miembro actualizado correctamente.");
    }

    [RelayCommand]
    private async Task EliminarAsync()
    {
        if (Seleccionado is null)
        {
            SetError("Seleccione un miembro de la lista para eliminarlo.");
            return;
        }

        var id = Seleccionado.Id;
        var nombre = Seleccionado.NombreCompleto;
        await RunAsync(async () =>
        {
            await Api.DeleteAsync($"api/miembros/{id}");
            await CargarListaAsync();
            Seleccionado = null;
            LimpiarCampos();
        }, $"Se eliminó a {nombre}.");
    }

    [RelayCommand]
    private void VolverInicio()
    {
        _mainViewModel.CurrentViewModel = new InicioViewModel(_mainViewModel);
    }
}
