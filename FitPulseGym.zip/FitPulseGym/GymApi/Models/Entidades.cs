using System.ComponentModel.DataAnnotations;

namespace GymApi.Models;

public class Miembro
{
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio."),
     StringLength(60, ErrorMessage = "El nombre no puede superar los 60 caracteres.")]
    public string Nombre { get; set; } = "";

    [Required(ErrorMessage = "El apellido es obligatorio."),
     StringLength(60, ErrorMessage = "El apellido no puede superar los 60 caracteres.")]
    public string Apellido { get; set; } = "";

    [Required(ErrorMessage = "El DNI es obligatorio."),
     RegularExpression(@"^\d{7,8}$", ErrorMessage = "El DNI debe tener 7 u 8 dígitos numéricos.")]
    public string Dni { get; set; } = "";

    [EmailAddress(ErrorMessage = "El email no tiene un formato válido."),
     StringLength(100, ErrorMessage = "El email no puede superar los 100 caracteres.")]
    public string? Email { get; set; }

    [RegularExpression(@"^[0-9+\-\s()]{6,20}$", ErrorMessage = "El teléfono no es válido (solo números, espacios, + - y paréntesis).")]
    public string? Telefono { get; set; }

    public DateTime FechaAlta { get; set; } = DateTime.Today;

    public bool Activo { get; set; } = true;
}

public class Entrenador
{
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio."),
     StringLength(60, ErrorMessage = "El nombre no puede superar los 60 caracteres.")]
    public string Nombre { get; set; } = "";

    [Required(ErrorMessage = "El apellido es obligatorio."),
     StringLength(60, ErrorMessage = "El apellido no puede superar los 60 caracteres.")]
    public string Apellido { get; set; } = "";

    [Required(ErrorMessage = "La especialidad es obligatoria."),
     StringLength(60, ErrorMessage = "La especialidad no puede superar los 60 caracteres.")]
    public string Especialidad { get; set; } = "";

    [EmailAddress(ErrorMessage = "El email no tiene un formato válido."),
     StringLength(100, ErrorMessage = "El email no puede superar los 100 caracteres.")]
    public string? Email { get; set; }
}

public class Maquina
{
    public int Id { get; set; }

    [Required(ErrorMessage = "El nombre de la máquina es obligatorio."),
     StringLength(80, ErrorMessage = "El nombre no puede superar los 80 caracteres.")]
    public string Nombre { get; set; } = "";

    [Required(ErrorMessage = "El músculo que entrena es obligatorio."),
     StringLength(60, ErrorMessage = "El músculo no puede superar los 60 caracteres.")]
    public string Musculo { get; set; } = "";
}

public class Pago
{
    public int Id { get; set; }
    public int MiembroId { get; set; }
    public Miembro? Miembro { get; set; }
    public decimal Monto { get; set; }
    public DateTime Fecha { get; set; }
    public string Concepto { get; set; } = "";
}
