using GymApi.Data;
using GymApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GymApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PagosController(GymContext db) : ControllerBase
{
    private IQueryable<PagoDto> Consulta() =>
        db.Pagos.AsNoTracking().Select(p => new PagoDto
        {
            Id = p.Id,
            MiembroId = p.MiembroId,
            MiembroNombre = p.Miembro!.Apellido + ", " + p.Miembro.Nombre,
            Monto = p.Monto,
            Fecha = p.Fecha,
            Concepto = p.Concepto
        });

    [HttpGet]
    public async Task<List<PagoDto>> Get() =>
        await Consulta().OrderByDescending(p => p.Fecha).ThenByDescending(p => p.Id).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<PagoDto>> GetById(int id)
    {
        var pago = await Consulta().FirstOrDefaultAsync(p => p.Id == id);
        return pago is null ? NoExiste(id) : pago;
    }

    [HttpPost]
    public async Task<ActionResult<PagoDto>> Post(PagoRequest request)
    {
        var error = await ValidarAsync(request);
        if (error is not null) return error;

        var pago = new Pago
        {
            MiembroId = request.MiembroId,
            Monto = request.Monto,
            Fecha = request.Fecha.Date,
            Concepto = request.Concepto.Trim()
        };
        db.Pagos.Add(pago);
        await db.SaveChangesAsync();

        var dto = await Consulta().FirstAsync(p => p.Id == pago.Id);
        return CreatedAtAction(nameof(GetById), new { id = pago.Id }, dto);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Put(int id, PagoRequest request)
    {
        var pago = await db.Pagos.FindAsync(id);
        if (pago is null) return NoExiste(id);

        var error = await ValidarAsync(request);
        if (error is not null) return error;

        pago.MiembroId = request.MiembroId;
        pago.Monto = request.Monto;
        pago.Fecha = request.Fecha.Date;
        pago.Concepto = request.Concepto.Trim();
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var pago = await db.Pagos.FindAsync(id);
        if (pago is null) return NoExiste(id);

        db.Pagos.Remove(pago);
        await db.SaveChangesAsync();
        return NoContent();
    }

    private async Task<ActionResult?> ValidarAsync(PagoRequest request)
    {
        if (request.Fecha.Date > DateTime.Today)
        {
            ModelState.AddModelError(nameof(request.Fecha), "La fecha del pago no puede ser futura.");
            return ValidationProblem(ModelState);
        }

        if (!await db.Miembros.AnyAsync(m => m.Id == request.MiembroId))
            return Problem(detail: "El miembro seleccionado no existe (puede haber sido eliminado).", statusCode: 404, title: "No encontrado");

        return null;
    }

    private ObjectResult NoExiste(int id) =>
        Problem(detail: $"El pago con id {id} no existe (puede haber sido eliminado).", statusCode: 404, title: "No encontrado");
}
