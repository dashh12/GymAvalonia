using GymApi.Data;
using GymApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GymApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MaquinasController(GymContext db) : ControllerBase
{
    [HttpGet]
    public async Task<List<Maquina>> Get() =>
        await db.Maquinas.AsNoTracking().OrderBy(m => m.Id).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Maquina>> GetById(int id)
    {
        var maquina = await db.Maquinas.AsNoTracking().FirstOrDefaultAsync(m => m.Id == id);
        return maquina is null ? NoExiste(id) : maquina;
    }

    [HttpPost]
    public async Task<ActionResult<Maquina>> Post(Maquina maquina)
    {
        maquina.Id = 0;
        db.Maquinas.Add(maquina);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = maquina.Id }, maquina);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Put(int id, Maquina datos)
    {
        var maquina = await db.Maquinas.FindAsync(id);
        if (maquina is null) return NoExiste(id);

        maquina.Nombre = datos.Nombre;
        maquina.Musculo = datos.Musculo;
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var maquina = await db.Maquinas.FindAsync(id);
        if (maquina is null) return NoExiste(id);

        db.Maquinas.Remove(maquina);
        await db.SaveChangesAsync();
        return NoContent();
    }

    private ObjectResult NoExiste(int id) =>
        Problem(detail: $"La máquina con id {id} no existe (puede haber sido eliminada).", statusCode: 404, title: "No encontrado");
}
