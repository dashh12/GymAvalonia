using GymApi.Models;
using Microsoft.EntityFrameworkCore;

namespace GymApi.Data;

public class GymContext(DbContextOptions<GymContext> options) : DbContext(options)
{
    public DbSet<Miembro> Miembros => Set<Miembro>();
    public DbSet<Entrenador> Entrenadores => Set<Entrenador>();
    public DbSet<Maquina> Maquinas => Set<Maquina>();
    public DbSet<Pago> Pagos => Set<Pago>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<Miembro>().HasIndex(m => m.Dni).IsUnique();

        mb.Entity<Pago>()
            .HasOne(p => p.Miembro)
            .WithMany()
            .HasForeignKey(p => p.MiembroId)
            .OnDelete(DeleteBehavior.Restrict);

        mb.Entity<Pago>().Property(p => p.Monto).HasPrecision(18, 2);
    }
}
