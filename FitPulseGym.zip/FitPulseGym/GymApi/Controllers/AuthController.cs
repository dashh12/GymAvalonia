using GymApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace GymApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController(IConfiguration config) : ControllerBase
{
    [HttpPost("login")]
    public IActionResult Login(LoginRequest request)
    {
        var usuario = config["Auth:Usuario"] ?? "admin";
        var clave = config["Auth:Clave"] ?? "admin123";

        if (!string.Equals(request.Usuario, usuario, StringComparison.OrdinalIgnoreCase) || request.Clave != clave)
            return Problem(detail: "Usuario o contraseña incorrectos.", statusCode: 401, title: "No autorizado");

        return Ok(new { usuario });
    }
}
