using GymApi.Data;
using GymApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GymApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class EntrenadoresController(GymContext db) : ControllerBase
{
    [HttpGet]
    public async Task<List<Entrenador>> Get() =>
        await db.Entrenadores.AsNoTracking().OrderBy(e => e.Apellido).ThenBy(e => e.Nombre).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Entrenador>> GetById(int id)
    {
        var entrenador = await db.Entrenadores.AsNoTracking().FirstOrDefaultAsync(e => e.Id == id);
        return entrenador is null ? NoExiste(id) : entrenador;
    }

    [HttpPost]
    public async Task<ActionResult<Entrenador>> Post(Entrenador entrenador)
    {
        entrenador.Id = 0;
        db.Entrenadores.Add(entrenador);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = entrenador.Id }, entrenador);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Put(int id, Entrenador datos)
    {
        var entrenador = await db.Entrenadores.FindAsync(id);
        if (entrenador is null) return NoExiste(id);

        entrenador.Nombre = datos.Nombre;
        entrenador.Apellido = datos.Apellido;
        entrenador.Especialidad = datos.Especialidad;
        entrenador.Email = datos.Email;
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var entrenador = await db.Entrenadores.FindAsync(id);
        if (entrenador is null) return NoExiste(id);

        db.Entrenadores.Remove(entrenador);
        await db.SaveChangesAsync();
        return NoContent();
    }

    private ObjectResult NoExiste(int id) =>
        Problem(detail: $"El entrenador con id {id} no existe (puede haber sido eliminado).", statusCode: 404, title: "No encontrado");
}
