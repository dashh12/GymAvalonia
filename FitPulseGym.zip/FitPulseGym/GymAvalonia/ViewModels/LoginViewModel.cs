using System.Collections.Generic;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MyAvaloniaApp.Models;
using MyAvaloniaApp.Services;

namespace MyAvaloniaApp.ViewModels;

public partial class LoginViewModel : ViewModelBase
{
    private readonly MainWindowViewModel _mainViewModel;

    [ObservableProperty] private string _usuario = "";
    [ObservableProperty] private string _clave = "";

    public LoginViewModel(MainWindowViewModel mainViewModel)
    {
        _mainViewModel = mainViewModel;
    }

    [RelayCommand]
    private async Task IniciarSesionAsync()
    {
        var errores = new List<string>();
        if (string.IsNullOrWhiteSpace(Usuario)) errores.Add("• Ingrese el usuario.");
        if (string.IsNullOrWhiteSpace(Clave)) errores.Add("• Ingrese la contraseña.");
        if (errores.Count > 0)
        {
            SetError(string.Join("\n", errores));
            return;
        }

        var ok = await RunAsync(() => Api.PostAsync("api/auth/login",
            new LoginRequest { Usuario = Usuario.Trim(), Clave = Clave }));

        if (ok)
            _mainViewModel.CurrentViewModel = new InicioViewModel(_mainViewModel);
    }
}
