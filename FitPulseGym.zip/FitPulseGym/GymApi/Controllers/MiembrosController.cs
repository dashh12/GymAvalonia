using GymApi.Data;
using GymApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GymApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class MiembrosController(GymContext db) : ControllerBase
{
    [HttpGet]
    public async Task<List<Miembro>> Get() =>
        await db.Miembros.AsNoTracking().OrderBy(m => m.Apellido).ThenBy(m => m.Nombre).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Miembro>> GetById(int id)
    {
        var miembro = await db.Miembros.AsNoTracking().FirstOrDefaultAsync(m => m.Id == id);
        return miembro is null ? NoExiste(id) : miembro;
    }

    [HttpPost]
    public async Task<ActionResult<Miembro>> Post(Miembro miembro)
    {
        if (await db.Miembros.AnyAsync(m => m.Dni == miembro.Dni))
            return Problem(detail: $"Ya existe un miembro con el DNI {miembro.Dni}.", statusCode: 409, title: "Dato duplicado");

        miembro.Id = 0;
        db.Miembros.Add(miembro);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = miembro.Id }, miembro);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Put(int id, Miembro datos)
    {
        var miembro = await db.Miembros.FindAsync(id);
        if (miembro is null) return NoExiste(id);

        if (await db.Miembros.AnyAsync(m => m.Dni == datos.Dni && m.Id != id))
            return Problem(detail: $"Ya existe otro miembro con el DNI {datos.Dni}.", statusCode: 409, title: "Dato duplicado");

        miembro.Nombre = datos.Nombre;
        miembro.Apellido = datos.Apellido;
        miembro.Dni = datos.Dni;
        miembro.Email = datos.Email;
        miembro.Telefono = datos.Telefono;
        miembro.Activo = datos.Activo;
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var miembro = await db.Miembros.FindAsync(id);
        if (miembro is null) return NoExiste(id);

        if (await db.Pagos.AnyAsync(p => p.MiembroId == id))
            return Problem(detail: "No se puede eliminar un miembro que tiene pagos registrados. Puede marcarlo como inactivo.",
                           statusCode: 409, title: "Conflicto");

        db.Miembros.Remove(miembro);
        await db.SaveChangesAsync();
        return NoContent();
    }

    private ObjectResult NoExiste(int id) =>
        Problem(detail: $"El miembro con id {id} no existe (puede haber sido eliminado).", statusCode: 404, title: "No encontrado");
}
