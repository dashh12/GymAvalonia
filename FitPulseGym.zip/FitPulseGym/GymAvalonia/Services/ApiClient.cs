using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;

namespace MyAvaloniaApp.Services;

/// <summary>Error de la API ya traducido a un mensaje listo para mostrar al usuario.</summary>
public class ApiException : Exception
{
    public int? StatusCode { get; }

    public ApiException(string message, int? statusCode = null) : base(message)
    {
        StatusCode = statusCode;
    }
}

public class ApiClient
{
    public static ApiClient Instance { get; } = new();

    private static readonly JsonSerializerOptions JsonOpts = new(JsonSerializerDefaults.Web);
    private readonly HttpClient _http;

    private ApiClient()
    {
        // Se puede cambiar la dirección con la variable de entorno GYM_API_URL
        var url = Environment.GetEnvironmentVariable("GYM_API_URL") ?? "http://localhost:5080/";
        if (!url.EndsWith('/')) url += "/";

        _http = new HttpClient
        {
            BaseAddress = new Uri(url),
            Timeout = TimeSpan.FromSeconds(8)
        };
    }

    public Task<T> GetAsync<T>(string path) => SendAsync<T>(HttpMethod.Get, path, null);
    public Task<T> PostAsync<T>(string path, object body) => SendAsync<T>(HttpMethod.Post, path, body);
    public Task PostAsync(string path, object body) => SendRawAsync(HttpMethod.Post, path, body);
    public Task PutAsync(string path, object body) => SendRawAsync(HttpMethod.Put, path, body);
    public Task DeleteAsync(string path) => SendRawAsync(HttpMethod.Delete, path, null);

    private async Task<T> SendAsync<T>(HttpMethod method, string path, object? body)
    {
        using var response = await SendRawAsync(method, path, body);
        try
        {
            var data = await response.Content.ReadFromJsonAsync<T>(JsonOpts);
            return data ?? throw new ApiException("El servidor devolvió una respuesta vacía.");
        }
        catch (JsonException)
        {
            throw new ApiException("El servidor devolvió una respuesta con un formato inesperado.");
        }
    }

    private async Task<HttpResponseMessage> SendRawAsync(HttpMethod method, string path, object? body)
    {
        try
        {
            using var request = new HttpRequestMessage(method, path);
            if (body is not null)
                request.Content = JsonContent.Create(body, body.GetType(), options: JsonOpts);

            var response = await _http.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                var error = await CrearErrorAsync(response);
                response.Dispose();
                throw error;
            }
            return response;
        }
        catch (ApiException)
        {
            throw;
        }
        catch (TaskCanceledException)
        {
            throw new ApiException("El servidor tardó demasiado en responder. Intente nuevamente.");
        }
        catch (HttpRequestException)
        {
            throw new ApiException($"No se pudo conectar con el servidor ({_http.BaseAddress}). Verifique que la API esté iniciada y vuelva a intentar.");
        }
    }

    private static async Task<ApiException> CrearErrorAsync(HttpResponseMessage response)
    {
        var code = (int)response.StatusCode;
        string? detalle = null;
        var errores = new List<string>();

        try
        {
            var texto = await response.Content.ReadAsStringAsync();
            if (!string.IsNullOrWhiteSpace(texto))
            {
                using var doc = JsonDocument.Parse(texto);
                var root = doc.RootElement;
                if (root.ValueKind == JsonValueKind.Object)
                {
                    if (root.TryGetProperty("detail", out var d) && d.ValueKind == JsonValueKind.String)
                        detalle = d.GetString();

                    if (root.TryGetProperty("errors", out var errs) && errs.ValueKind == JsonValueKind.Object)
                    {
                        foreach (var campo in errs.EnumerateObject())
                            if (campo.Value.ValueKind == JsonValueKind.Array)
                                foreach (var msg in campo.Value.EnumerateArray())
                                    if (msg.GetString() is { } m) errores.Add("• " + m);
                    }
                }
            }
        }
        catch (Exception)
        {
            // Si el cuerpo no es JSON, se usa el mensaje genérico según el código HTTP.
        }

        if (errores.Count > 0)
            return new ApiException("El servidor rechazó los datos:\n" + string.Join("\n", errores), code);

        return response.StatusCode switch
        {
            HttpStatusCode.BadRequest => new ApiException(detalle ?? "Los datos enviados no son válidos.", code),
            HttpStatusCode.Unauthorized => new ApiException(detalle ?? "No autorizado.", code),
            HttpStatusCode.NotFound => new ApiException(detalle ?? "El dato solicitado no existe.", code),
            HttpStatusCode.Conflict => new ApiException(detalle ?? "La operación entra en conflicto con datos existentes.", code),
            _ when code >= 500 => new ApiException("El servidor tuvo un error interno. Intente nuevamente en unos minutos.", code),
            _ => new ApiException(detalle ?? $"Error inesperado del servidor (código {code}).", code)
        };
    }
}
