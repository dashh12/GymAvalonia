using System;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using MyAvaloniaApp.Services;

namespace MyAvaloniaApp.ViewModels;

public partial class ViewModelBase : ObservableObject
{
    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(HasError))]
    private string? _errorMessage;

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(HasInfo))]
    private string? _infoMessage;

    [ObservableProperty]
    private bool _isBusy;

    /// <summary>True cuando la lista cargó bien pero no hay datos.</summary>
    [ObservableProperty]
    private bool _sinDatos;

    public bool HasError => !string.IsNullOrWhiteSpace(ErrorMessage);
    public bool HasInfo => !string.IsNullOrWhiteSpace(InfoMessage);

    protected ApiClient Api => ApiClient.Instance;

    protected void SetError(string mensaje)
    {
        InfoMessage = null;
        ErrorMessage = mensaje;
    }

    /// <summary>
    /// Ejecuta una operación contra la API mostrando el estado de carga y
    /// cualquier error (conexión, validación, datos inexistentes, etc.) en pantalla.
    /// </summary>
    protected async Task<bool> RunAsync(Func<Task> accion, string? mensajeOk = null)
    {
        IsBusy = true;
        ErrorMessage = null;
        InfoMessage = null;
        try
        {
            await accion();
            if (mensajeOk is not null) InfoMessage = mensajeOk;
            return true;
        }
        catch (ApiException ex)
        {
            ErrorMessage = ex.Message;
            return false;
        }
        catch (Exception ex)
        {
            ErrorMessage = "Ocurrió un error inesperado: " + ex.Message;
            return false;
        }
        finally
        {
            IsBusy = false;
        }
    }
}
