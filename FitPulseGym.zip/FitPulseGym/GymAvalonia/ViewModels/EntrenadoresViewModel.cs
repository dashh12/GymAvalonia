using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MyAvaloniaApp.Models;
using MyAvaloniaApp.Services;

namespace MyAvaloniaApp.ViewModels;

public partial class EntrenadoresViewModel : ViewModelBase
{
    private readonly MainWindowViewModel _mainViewModel;

    public ObservableCollection<Entrenador> Entrenadores { get; } = new();

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(TituloFormulario))]
    private Entrenador? _seleccionado;

    [ObservableProperty] private string _nombre = "";
    [ObservableProperty] private string _apellido = "";
    [ObservableProperty] private string _especialidad = "";
    [ObservableProperty] private string _email = "";

    public string TituloFormulario => Seleccionado is null ? "Nuevo entrenador" : "Editar entrenador";

    public EntrenadoresViewModel(MainWindowViewModel mainViewModel)
    {
        _mainViewModel = mainViewModel;
        _ = CargarAsync();
    }

    partial void OnSeleccionadoChanged(Entrenador? value)
    {
        if (value is null)
        {
            LimpiarCampos();
            return;
        }

        Nombre = value.Nombre;
        Apellido = value.Apellido;
        Especialidad = value.Especialidad;
        Email = value.Email ?? "";
        ErrorMessage = null;
        InfoMessage = null;
    }

    private void LimpiarCampos()
    {
        Nombre = Apellido = Especialidad = Email = "";
    }

    private async Task CargarListaAsync()
    {
        var lista = await Api.GetAsync<List<Entrenador>>("api/entrenadores");
        Entrenadores.Clear();
        foreach (var e in lista) Entrenadores.Add(e);
        SinDatos = Entrenadores.Count == 0;
    }

    [RelayCommand]
    private Task CargarAsync() => RunAsync(CargarListaAsync);

    [RelayCommand]
    private void Nuevo()
    {
        ErrorMessage = null;
        InfoMessage = null;
        Seleccionado = null;
        LimpiarCampos();
    }

    [RelayCommand]
    private async Task GuardarAsync()
    {
        var errores = new List<string>();
        Validador.Requerido(errores, Nombre, "El nombre");
        Validador.Requerido(errores, Apellido, "El apellido");
        Validador.Requerido(errores, Especialidad, "La especialidad");
        Validador.Email(errores, Email);
        if (errores.Count > 0)
        {
            SetError("Revise los datos ingresados:\n" + string.Join("\n", errores));
            return;
        }

        var datos = new Entrenador
        {
            Nombre = Nombre.Trim(),
            Apellido = Apellido.Trim(),
            Especialidad = Especialidad.Trim(),
            Email = Validador.NullSiVacio(Email)
        };
        var editando = Seleccionado;

        await RunAsync(async () =>
        {
            if (editando is null)
                await Api.PostAsync<Entrenador>("api/entrenadores", datos);
            else
                await Api.PutAsync($"api/entrenadores/{editando.Id}", datos);

            await CargarListaAsync();
            Seleccionado = null;
            LimpiarCampos();
        }, editando is null ? "Entrenador registrado correctamente." : "Entrenador actualizado correctamente.");
    }

    [RelayCommand]
    private async Task EliminarAsync()
    {
        if (Seleccionado is null)
        {
            SetError("Seleccione un entrenador de la lista para eliminarlo.");
            return;
        }

        var id = Seleccionado.Id;
        var nombre = Seleccionado.NombreCompleto;
        await RunAsync(async () =>
        {
            await Api.DeleteAsync($"api/entrenadores/{id}");
            await CargarListaAsync();
            Seleccionado = null;
            LimpiarCampos();
        }, $"Se eliminó a {nombre}.");
    }

    [RelayCommand]
    private void VolverInicio()
    {
        _mainViewModel.CurrentViewModel = new InicioViewModel(_mainViewModel);
    }
}
