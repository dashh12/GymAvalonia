using GymApi.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

// Base de datos SQL (SQLite): se crea sola en la carpeta del proyecto la primera vez que se ejecuta.
var rutaDb = Path.Combine(builder.Environment.ContentRootPath, "gym.db");
builder.Services.AddDbContext<GymContext>(o => o.UseSqlite($"Data Source={rutaDb}"));

var app = builder.Build();

// Cualquier error no controlado se devuelve como JSON con un mensaje claro (nunca una pantalla de error).
app.UseExceptionHandler(errorApp => errorApp.Run(async context =>
{
    context.Response.StatusCode = StatusCodes.Status500InternalServerError;
    await context.Response.WriteAsJsonAsync(new ProblemDetails
    {
        Status = 500,
        Title = "Error interno",
        Detail = "Ocurrió un error inesperado en el servidor."
    });
}));

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<GymContext>();
    db.Database.EnsureCreated();
    DbSeeder.Seed(db);
}

app.MapGet("/api/salud", () => Results.Ok(new { estado = "ok" }));
app.MapControllers();

app.Run();
