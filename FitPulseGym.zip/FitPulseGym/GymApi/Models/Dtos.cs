using System.ComponentModel.DataAnnotations;

namespace GymApi.Models;

public class PagoRequest
{
    [Range(1, int.MaxValue, ErrorMessage = "Debe seleccionar un miembro.")]
    public int MiembroId { get; set; }

    [Range(typeof(decimal), "0.01", "10000000", ErrorMessage = "El monto debe ser mayor a 0 y menor a 10.000.000.")]
    public decimal Monto { get; set; }

    public DateTime Fecha { get; set; } = DateTime.Today;

    [Required(ErrorMessage = "El concepto es obligatorio."),
     StringLength(100, ErrorMessage = "El concepto no puede superar los 100 caracteres.")]
    public string Concepto { get; set; } = "";
}

public class PagoDto
{
    public int Id { get; set; }
    public int MiembroId { get; set; }
    public string MiembroNombre { get; set; } = "";
    public decimal Monto { get; set; }
    public DateTime Fecha { get; set; }
    public string Concepto { get; set; } = "";
}

public class LoginRequest
{
    [Required(ErrorMessage = "El usuario es obligatorio.")]
    public string Usuario { get; set; } = "";

    [Required(ErrorMessage = "La contraseña es obligatoria.")]
    public string Clave { get; set; } = "";
}
