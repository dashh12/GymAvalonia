using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MyAvaloniaApp.Models;
using MyAvaloniaApp.Services;

namespace MyAvaloniaApp.ViewModels;

public partial class PagosViewModel : ViewModelBase
{
    private readonly MainWindowViewModel _mainViewModel;

    public ObservableCollection<Pago> Pagos { get; } = new();
    public ObservableCollection<Miembro> Miembros { get; } = new();

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(TituloFormulario))]
    private Pago? _seleccionado;

    [ObservableProperty] private Miembro? _miembroSeleccionado;
    [ObservableProperty] private string _monto = "";
    [ObservableProperty] private DateTime? _fecha = DateTime.Today;
    [ObservableProperty] private string _concepto = "";

    public string TituloFormulario => Seleccionado is null ? "Nuevo pago" : "Editar pago";

    public PagosViewModel(MainWindowViewModel mainViewModel)
    {
        _mainViewModel = mainViewModel;
        _ = CargarAsync();
    }

    partial void OnSeleccionadoChanged(Pago? value)
    {
        if (value is null)
        {
            LimpiarCampos();
            return;
        }

        MiembroSeleccionado = Miembros.FirstOrDefault(m => m.Id == value.MiembroId);
        Monto = value.Monto.ToString("0.00", CultureInfo.InvariantCulture);
        Fecha = value.Fecha;
        Concepto = value.Concepto;
        ErrorMessage = null;
        InfoMessage = null;
    }

    private void LimpiarCampos()
    {
        MiembroSeleccionado = null;
        Monto = "";
        Fecha = DateTime.Today;
        Concepto = "";
    }

    private async Task CargarListaAsync()
    {
        var miembros = await Api.GetAsync<List<Miembro>>("api/miembros");
        var pagos = await Api.GetAsync<List<Pago>>("api/pagos");

        Miembros.Clear();
        foreach (var m in miembros) Miembros.Add(m);

        Pagos.Clear();
        foreach (var p in pagos) Pagos.Add(p);

        SinDatos = Pagos.Count == 0;
    }

    [RelayCommand]
    private Task CargarAsync() => RunAsync(CargarListaAsync);

    [RelayCommand]
    private void Nuevo()
    {
        ErrorMessage = null;
        InfoMessage = null;
        Seleccionado = null;
        LimpiarCampos();
    }

    [RelayCommand]
    private async Task GuardarAsync()
    {
        var errores = new List<string>();

        if (MiembroSeleccionado is null)
            errores.Add(Miembros.Count == 0
                ? "• No hay miembros registrados: primero cargue un miembro."
                : "• Seleccione el miembro que realiza el pago.");

        decimal monto = 0;
        if (!Validador.TryMonto(Monto, out monto))
            errores.Add("• El monto es obligatorio y debe ser un número (ej: 25000 o 25000,50).");
        else if (monto <= 0)
            errores.Add("• El monto debe ser mayor a 0.");
        else if (monto > 10_000_000m)
            errores.Add("• El monto no puede superar los 10.000.000.");

        if (Fecha is null)
            errores.Add("• La fecha es obligatoria.");
        else if (Fecha.Value.Date > DateTime.Today)
            errores.Add("• La fecha del pago no puede ser futura.");

        Validador.Requerido(errores, Concepto, "El concepto", 100);

        if (errores.Count > 0)
        {
            SetError("Revise los datos ingresados:\n" + string.Join("\n", errores));
            return;
        }

        var datos = new PagoRequest
        {
            MiembroId = MiembroSeleccionado!.Id,
            Monto = monto,
            Fecha = Fecha!.Value.Date,
            Concepto = Concepto.Trim()
        };
        var editando = Seleccionado;

        await RunAsync(async () =>
        {
            if (editando is null)
                await Api.PostAsync<Pago>("api/pagos", datos);
            else
                await Api.PutAsync($"api/pagos/{editando.Id}", datos);

            await CargarListaAsync();
            Seleccionado = null;
            LimpiarCampos();
        }, editando is null ? "Pago registrado correctamente." : "Pago actualizado correctamente.");
    }

    [RelayCommand]
    private async Task EliminarAsync()
    {
        if (Seleccionado is null)
        {
            SetError("Seleccione un pago de la lista para eliminarlo.");
            return;
        }

        var id = Seleccionado.Id;
        await RunAsync(async () =>
        {
            await Api.DeleteAsync($"api/pagos/{id}");
            await CargarListaAsync();
            Seleccionado = null;
            LimpiarCampos();
        }, "Pago eliminado.");
    }

    [RelayCommand]
    private void VolverInicio()
    {
        _mainViewModel.CurrentViewModel = new InicioViewModel(_mainViewModel);
    }
}
