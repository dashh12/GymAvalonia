using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MyAvaloniaApp.Models;
using MyAvaloniaApp.Services;

namespace MyAvaloniaApp.ViewModels;

public partial class MaquinariaViewModel : ViewModelBase
{
    private readonly MainWindowViewModel _mainViewModel;

    public ObservableCollection<Maquina> Maquinas { get; } = new();

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(TituloFormulario))]
    private Maquina? _seleccionada;

    [ObservableProperty] private string _nombre = "";
    [ObservableProperty] private string _musculo = "";

    public string TituloFormulario => Seleccionada is null ? "Nueva máquina" : "Editar máquina";

    public MaquinariaViewModel(MainWindowViewModel mainViewModel)
    {
        _mainViewModel = mainViewModel;
        _ = CargarAsync();
    }

    partial void OnSeleccionadaChanged(Maquina? value)
    {
        if (value is null)
        {
            Nombre = Musculo = "";
            return;
        }

        Nombre = value.Nombre;
        Musculo = value.Musculo;
        ErrorMessage = null;
        InfoMessage = null;
    }

    private async Task CargarListaAsync()
    {
        var lista = await Api.GetAsync<List<Maquina>>("api/maquinas");
        Maquinas.Clear();
        foreach (var m in lista) Maquinas.Add(m);
        SinDatos = Maquinas.Count == 0;
    }

    [RelayCommand]
    private Task CargarAsync() => RunAsync(CargarListaAsync);

    [RelayCommand]
    private void Nuevo()
    {
        ErrorMessage = null;
        InfoMessage = null;
        Seleccionada = null;
        Nombre = Musculo = "";
    }

    [RelayCommand]
    private async Task GuardarAsync()
    {
        var errores = new List<string>();
        Validador.Requerido(errores, Nombre, "El nombre de la máquina", 80);
        Validador.Requerido(errores, Musculo, "El músculo que entrena");
        if (errores.Count > 0)
        {
            SetError("Revise los datos ingresados:\n" + string.Join("\n", errores));
            return;
        }

        var datos = new Maquina { Nombre = Nombre.Trim(), Musculo = Musculo.Trim() };
        var editando = Seleccionada;

        await RunAsync(async () =>
        {
            if (editando is null)
                await Api.PostAsync<Maquina>("api/maquinas", datos);
            else
                await Api.PutAsync($"api/maquinas/{editando.Id}", datos);

            await CargarListaAsync();
            Seleccionada = null;
            Nombre = Musculo = "";
        }, editando is null ? "Máquina registrada correctamente." : "Máquina actualizada correctamente.");
    }

    [RelayCommand]
    private async Task EliminarAsync()
    {
        if (Seleccionada is null)
        {
            SetError("Seleccione una máquina de la lista para eliminarla.");
            return;
        }

        var id = Seleccionada.Id;
        var nombre = Seleccionada.Nombre;
        await RunAsync(async () =>
        {
            await Api.DeleteAsync($"api/maquinas/{id}");
            await CargarListaAsync();
            Seleccionada = null;
            Nombre = Musculo = "";
        }, $"Se eliminó la máquina \"{nombre}\".");
    }

    [RelayCommand]
    private void VolverAlInicio()
    {
        _mainViewModel.CurrentViewModel = new InicioViewModel(_mainViewModel);
    }
}
