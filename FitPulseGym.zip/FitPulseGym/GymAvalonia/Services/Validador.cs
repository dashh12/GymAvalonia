using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;

namespace MyAvaloniaApp.Services;

/// <summary>Validaciones de entrada que se hacen en la app antes de llamar a la API.</summary>
public static class Validador
{
    private static readonly Regex EmailRx = new(@"^[^@\s]+@[^@\s]+\.[^@\s]+$");
    private static readonly Regex DniRx = new(@"^\d{7,8}$");
    private static readonly Regex TelefonoRx = new(@"^[0-9+\-\s()]{6,20}$");

    public static void Requerido(List<string> errores, string? valor, string campo, int max = 60)
    {
        if (string.IsNullOrWhiteSpace(valor))
            errores.Add($"• {campo} es obligatorio.");
        else if (valor.Trim().Length > max)
            errores.Add($"• {campo} no puede superar los {max} caracteres.");
    }

    public static void Dni(List<string> errores, string? valor)
    {
        if (string.IsNullOrWhiteSpace(valor))
            errores.Add("• El DNI es obligatorio.");
        else if (!DniRx.IsMatch(valor.Trim()))
            errores.Add("• El DNI debe tener 7 u 8 dígitos numéricos (sin puntos).");
    }

    public static void Email(List<string> errores, string? valor)
    {
        if (!string.IsNullOrWhiteSpace(valor) && !EmailRx.IsMatch(valor.Trim()))
            errores.Add("• El email no tiene un formato válido (ej: nombre@mail.com).");
    }

    public static void Telefono(List<string> errores, string? valor)
    {
        if (!string.IsNullOrWhiteSpace(valor) && !TelefonoRx.IsMatch(valor.Trim()))
            errores.Add("• El teléfono no es válido (solo números, espacios, + - y paréntesis).");
    }

    /// <summary>Acepta "25000", "25000.50" y "25.000,50".</summary>
    public static bool TryMonto(string? texto, out decimal monto)
    {
        monto = 0;
        if (string.IsNullOrWhiteSpace(texto)) return false;

        var s = texto.Trim();
        if (s.Contains(','))
            s = s.Replace(".", "").Replace(',', '.');

        return decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out monto);
    }

    public static string? NullSiVacio(string? valor) =>
        string.IsNullOrWhiteSpace(valor) ? null : valor.Trim();
}
