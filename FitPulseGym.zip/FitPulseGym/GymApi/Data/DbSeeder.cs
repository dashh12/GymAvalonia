using GymApi.Models;

namespace GymApi.Data;

public static class DbSeeder
{
    public static void Seed(GymContext db)
    {
        if (!db.Miembros.Any())
        {
            var hoy = DateTime.Today;
            db.Miembros.AddRange(
                new Miembro { Nombre = "Lucía", Apellido = "Fernández", Dni = "40123456", Email = "lucia@mail.com", Telefono = "2954 411122", FechaAlta = hoy.AddMonths(-6) },
                new Miembro { Nombre = "Martín", Apellido = "Gómez", Dni = "38987654", Email = "martin@mail.com", Telefono = "2954 433344", FechaAlta = hoy.AddMonths(-4) },
                new Miembro { Nombre = "Sofía", Apellido = "Pérez", Dni = "42555111", Email = null, Telefono = "2954 455566", FechaAlta = hoy.AddMonths(-2) },
                new Miembro { Nombre = "Julián", Apellido = "Rodríguez", Dni = "36777888", Email = "julian@mail.com", Telefono = null, FechaAlta = hoy.AddMonths(-1), Activo = false });
            db.SaveChanges();
        }

        if (!db.Entrenadores.Any())
        {
            db.Entrenadores.AddRange(
                new Entrenador { Nombre = "Carlos", Apellido = "Méndez", Especialidad = "Musculación", Email = "carlos@fitpulse.com" },
                new Entrenador { Nombre = "Valeria", Apellido = "Ríos", Especialidad = "Funcional", Email = "valeria@fitpulse.com" },
                new Entrenador { Nombre = "Diego", Apellido = "Sosa", Especialidad = "Crossfit", Email = null });
            db.SaveChanges();
        }

        if (!db.Maquinas.Any())
        {
            db.Maquinas.AddRange(
                new Maquina { Nombre = "Press de banca", Musculo = "Pecho" },
                new Maquina { Nombre = "Peck deck", Musculo = "Pecho" },
                new Maquina { Nombre = "Polea alta", Musculo = "Espalda" },
                new Maquina { Nombre = "Remo en máquina", Musculo = "Espalda" },
                new Maquina { Nombre = "Press de hombros", Musculo = "Hombros" },
                new Maquina { Nombre = "Curl de bíceps", Musculo = "Bíceps" },
                new Maquina { Nombre = "Extensión de tríceps", Musculo = "Tríceps" },
                new Maquina { Nombre = "Prensa de piernas", Musculo = "Piernas" },
                new Maquina { Nombre = "Camilla de cuádriceps", Musculo = "Cuádriceps" },
                new Maquina { Nombre = "Camilla femoral", Musculo = "Isquiotibiales" },
                new Maquina { Nombre = "Abductores", Musculo = "Glúteos" },
                new Maquina { Nombre = "Abdominales en máquina", Musculo = "Abdomen" });
            db.SaveChanges();
        }

        if (!db.Pagos.Any())
        {
            var miembros = db.Miembros.OrderBy(m => m.Id).ToList();
            var hoy = DateTime.Today;
            db.Pagos.AddRange(
                new Pago { MiembroId = miembros[0].Id, Monto = 25000m, Fecha = hoy.AddDays(-30), Concepto = "Cuota mensual" },
                new Pago { MiembroId = miembros[0].Id, Monto = 25000m, Fecha = hoy.AddDays(-2), Concepto = "Cuota mensual" },
                new Pago { MiembroId = miembros[1].Id, Monto = 25000m, Fecha = hoy.AddDays(-10), Concepto = "Cuota mensual" },
                new Pago { MiembroId = miembros[2].Id, Monto = 8000m, Fecha = hoy.AddDays(-5), Concepto = "Inscripción" });
            db.SaveChanges();
        }
    }
}
